export const RenderLogo = '/assets/Render logo - Black.png';
export const InfinityFreeLogo = '/assets/Infinity free logo.svg';
