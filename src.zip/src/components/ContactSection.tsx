import React from 'react';
import { Mail, Github, Linkedin } from 'lucide-react';

interface SocialLinkProps {
  icon: React.ReactNode;
  href: string;
  label: string;
}

const SocialLink = ({ icon, href, label }: SocialLinkProps) => (
  <a
    href={href}
    target="_blank"
    rel="noopener noreferrer"
    className="inline-flex flex-col items-center p-3 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors duration-300 group"
    aria-label={label}
  >
    <div className="text-blue-600 dark:text-blue-400 group-hover:scale-110 transition-transform duration-200">
      {icon}
    </div>
    <span className="mt-2 text-sm font-medium dark:text-gray-300 text-gray-700 group-hover:text-blue-600 dark:group-hover:text-blue-400">
      {label}
    </span>
  </a>
);

const ContactSection: React.FC = () => (
  <section id="contact" className="py-20 px-4 border-t border-gray-200 dark:border-gray-800">
    <h2 className="text-4xl font-bold text-center mb-12 dark:text-gray-100 flex items-center justify-center">
      <Mail className="mr-3 w-8 h-8 text-blue-500" />
      Get In Touch
    </h2>
    <div className="max-w-xl mx-auto text-center dark:text-gray-300 text-gray-700 leading-relaxed text-lg">
      <p className="mb-8">
        I'm always open to new opportunities and collaborations. Feel free to reach out if you have any questions or just want to connect!
      </p>
      <div className="flex justify-center space-x-6 mb-8">
        <SocialLink icon={<Mail className="w-8 h-8" />} href="mailto:omkarvenkat09@gmail.com" label="Email" />
        <SocialLink icon={<Github className="w-8 h-8" />} href="https://github.com/Omkar-733" label="GitHub" />
        <SocialLink icon={<Linkedin className="w-8 h-8" />} href="https://linkedin.com/in/omkarvenkatgogula" label="LinkedIn" />
      </div>
      <p className="text-base">
        You can also send a direct message to <a href="mailto:omkarvenkat09@gmail.com" className="text-blue-600 hover:underline dark:text-blue-400">omkarvenkat09@gmail.com</a>.
      </p>
    </div>
  </section>
);

export default ContactSection;
