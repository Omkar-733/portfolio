import React from 'react';
import { Code, Sparkles } from 'lucide-react';

const HeroSection: React.FC = () => {
  return (
    <section 
      id="hero" 
      className="relative flex flex-col items-center justify-center min-h-[70vh] text-center py-20 px-4 overflow-hidden"
    >
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-600/10 to-purple-600/10 dark:from-blue-900/10 dark:to-purple-900/10 pointer-events-none" />

      <div className="relative z-10">
        <div className="max-w-4xl">
          <div className="flex items-center justify-center mb-8">
            <Code className="w-12 h-12 text-blue-500 dark:text-blue-400 mr-4" />
            <h1 className="text-4xl md:text-6xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-500 to-purple-500 dark:from-blue-400 dark:to-purple-400">
              Omkar Venkat Gogula
            </h1>
          </div>

          <p className="text-xl md:text-2xl text-gray-700 dark:text-gray-300 mb-8 max-w-2xl mx-auto">
            Full Stack Developer | AI/ML Enthusiast | Problem Solver
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="#contact"
              className="inline-flex items-center px-6 py-3 bg-blue-600 text-white rounded-lg shadow-lg hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-400 transition-all duration-300 transform hover:scale-105"
            >
              Get In Touch
              <Sparkles className="ml-2 w-4 h-4" />
            </a>
            <a
              href="https://github.com/Omkar-733"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center px-6 py-3 border-2 border-blue-600 text-blue-600 rounded-lg hover:bg-blue-600 hover:text-white dark:border-blue-400 dark:text-blue-400 dark:hover:bg-blue-400 transition-all duration-300 transform hover:scale-105"
            >
              View My Work
              <Sparkles className="ml-2 w-4 h-4" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
