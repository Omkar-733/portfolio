import React from 'react';
import { Briefcase } from 'lucide-react';

interface Project {
  title: string;
  description: string;
  techStack: string[];
  link: string;
  demo?: string;
  image: string;
}

const projects: Project[] = [
  {
    title: 'Digital Logbook System',
    description: 'Created a digital platform for logging student activities, enhancing record-keeping accuracy and reducing paper usage with a user-friendly interface.',
    techStack: ['PHP', 'MySQL'],
    link: 'https://github.com/Omkar-733/logger',
    demo: 'https://DigitalLogBook.ct.ws',
    image: 'https://placehold.co/600x400/2563EB/FFFFFF?text=Digital+Logbook'
  },
  {
    title: 'Link Shrinker',
    description: 'Built a URL shortening tool allowing dynamic link generation and tracking, using MongoDB to store original/shortened URLs and implemented click analytics.',
    techStack: ['Node.js', 'Express.js', 'MongoDB'],
    link: 'https://github.com/Omkar-733/Shrinkoo',
    demo: 'https://Shirnkoo.vercel.app/',
    image: 'https://placehold.co/600x400/2563EB/FFFFFF?text=Link+Shrinker'
  },
  {
    title: 'Student Feedback System',
    description: 'Designed a feedback collection platform to evaluate course and faculty effectiveness. Enabled structured data analysis for academic improvement through admin-controlled reports.',
    techStack: ['HTML', 'PHP', 'MySQL'],
    link: 'https://github.com/Omkar-733/Student-Feedback',
    image: 'https://placehold.co/600x400/2563EB/FFFFFF?text=Student+Feedback'
  },
  {
    title: 'Defect Handling System',
    description: 'Developed at Visakhapatnam Steel Plant to log, track, and manage issues, enhancing operational efficiency and real-time defect resolution.',
    techStack: ['Java Servlets', 'JSP', 'Oracle Database'],
    link: 'https://github.com/Omkar-733/Defect-Handling-System',
    image: 'https://placehold.co/600x400/2563EB/FFFFFF?text=Defect+Handling'
  }
];

const ProjectCard: React.FC<{ project: Project }> = ({ project }) => {
  const handleImageError = (event: React.SyntheticEvent<HTMLImageElement>) => {
    const img = event.currentTarget;
    img.src = '/placeholder-project.png';
  };

  return (
    <div className="rounded-xl shadow-lg overflow-hidden transform transition-all duration-300 hover:scale-[1.02] border border-gray-200">
      <img
        src={project.image}
        alt={project.title}
        className="w-full h-56 object-cover"
        onError={handleImageError}
      />
      <div className="p-6">
        <h3 className="text-2xl font-bold mb-3">
          <a href={project.demo || project.link} target="_blank" rel="noopener noreferrer" className="hover:text-blue-600">
            {project.title}
          </a>
        </h3>
        <p className="dark:text-gray-300 text-gray-700 mb-4 text-base transition-colors duration-200">{project.description}</p>
        <div className="flex flex-wrap gap-2 mb-4 transition-transform duration-200">
          {project.techStack.map((tech, index) => (
            <span key={index} className="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded-full dark:bg-blue-900 dark:text-blue-100 transition-colors duration-200">
              {tech}
            </span>
          ))}
        </div>
        <a
          href={project.link}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center text-blue-600 hover:text-blue-800 font-semibold transition-colors duration-200"
        >
          View Code
          <svg className="ml-2 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path>
          </svg>
        </a>
      </div>
    </div>
  );
};

const ProjectsSection: React.FC = () => (
  <section id="projects" className="py-20 px-4">
    <h2 className="text-4xl font-bold text-center mb-12 flex items-center justify-center">
      <Briefcase className="mr-3 w-8 h-8 text-blue-500" />
      My Projects
    </h2>
    <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-12">
      {projects.map((project, index) => (
        <ProjectCard key={index} project={project} />
      ))}
    </div>
  </section>
);

export default ProjectsSection;
