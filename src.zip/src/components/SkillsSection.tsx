import React from 'react';
import { Star } from 'lucide-react';
import './SkillsSection.css';
// Using cdn.jsdelivr.net for official brand logos
const Python = 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg';
const ReactLogo = 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/react/react-original.svg';
const Java = 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg';
const JavaScript = 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg';
const PHP = 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/php/php-original.svg';
const HTML5 = 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg';
const CSS3 = 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-original.svg';
const Nodejs = 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/nodejs/nodejs-original.svg';
const Express = 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/express/express-original.svg';
const MongoDB = 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mongodb/mongodb-original.svg';
const MySQL = 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original.svg';
const Git = 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/git/git-original.svg';
const Docker = 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/docker/docker-original.svg';
const AWS = 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/amazonwebservices/amazonwebservices-original.svg';
const TensorFlow = 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/tensorflow/tensorflow-original.svg';
const PyTorch = 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/pytorch/pytorch-original.svg';
const OpenCV = 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/opencv/opencv-original.svg';
const Render = '/logos/render-logo-black.png';
const InfinityFree = '/logos/infinity-free-logo.svg';

const SkillsSection: React.FC = () => {
  interface Skill {
    name: string;
    category: string;
    icon: string;
  }

  const skills: Skill[] = [
    // Programming Languages
    { 
      name: 'Python', 
      category: 'Programming Languages',
      icon: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg'
    },
    { 
      name: 'React', 
      category: 'Programming Languages',
      icon: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/react/react-original.svg'
    },
    { 
      name: 'Java', 
      category: 'Programming Languages',
      icon: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg'
    },
    { 
      name: 'JavaScript', 
      category: 'Programming Languages',
      icon: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg'
    },
    { 
      name: 'C++', 
      category: 'Programming Languages',
      icon: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/cplusplus/cplusplus-original.svg'
    },
    { 
      name: 'PHP', 
      category: 'Programming Languages',
      icon: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/php/php-original.svg'
    },

    // Frontend
    { 
      name: 'React', 
      category: 'Frontend',
      icon: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/react/react-original.svg'
    },
    { 
      name: 'Next.js', 
      category: 'Frontend',
      icon: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/nextjs/nextjs-original.svg'
    },
    { 
      name: 'HTML5', 
      category: 'Frontend',
      icon: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg'
    },
    { 
      name: 'CSS3', 
      category: 'Frontend',
      icon: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-original.svg'
    },
    { 
      name: 'Tailwind CSS', 
      category: 'Frontend',
      icon: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/tailwindcss/tailwindcss-original.svg'
    },
    { 
      name: 'Bootstrap', 
      category: 'Frontend',
      icon: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/bootstrap/bootstrap-original.svg'
    },

    // Backend
    { 
      name: 'Node.js', 
      category: 'Backend',
      icon: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/nodejs/nodejs-original.svg'
    },
    { 
      name: 'Express.js', 
      category: 'Backend',
      icon: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/express/express-original.svg'
    },
    { 
      name: 'PHP', 
      category: 'Backend',
      icon: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/php/php-original.svg'
    },
    { 
      name: 'RESTful APIs', 
      category: 'Backend',
      icon: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/nodejs/nodejs-original.svg'
    },

    // Database
    { 
      name: 'MongoDB', 
      category: 'Database',
      icon: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mongodb/mongodb-original.svg'
    },
    { 
      name: 'MySQL', 
      category: 'Database',
      icon: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original.svg'
    },
    { 
      name: 'Firebase', 
      category: 'Database',
      icon: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/firebase/firebase-plain.svg'
    },

    // Cloud & Tools
    { 
      name: 'Git', 
      category: 'Cloud & Tools',
      icon: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/git/git-original.svg'
    },
    { 
      name: 'REST APIs', 
      category: 'Cloud & Tools',
      icon: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/nodejs/nodejs-original.svg'
    },
    { 
      name: 'Google Gemini API', 
      category: 'Cloud & Tools',
      icon: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/googlecloud/googlecloud-original.svg'
    },
    { 
      name: 'Android Studio', 
      category: 'Cloud & Tools',
      icon: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/android/android-original.svg'
    },

    // Deployment
    { 
      name: 'Vercel', 
      category: 'Deployment',
      icon: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/vercel/vercel-original.svg'
    },
    { 
      name: 'Render', 
      category: 'Deployment',
      icon: Render
    },
    { 
      name: 'InfinityFree', 
      category: 'Deployment',
      icon: InfinityFree
    }
  ];

  const groupedSkills = skills.reduce((acc, skill) => {
    const category = skill.category;
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push(skill);
    return acc;
  }, {} as Record<string, Skill[]>);

  return (
    <section 
      id="skills" 
      className="py-20 px-4 border-t border-gray-200 dark:border-gray-800 relative overflow-hidden"
    >
      {/* Background pattern */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50/5 to-purple-50/5 dark:from-blue-900/5 dark:to-purple-900/5 pointer-events-none">
        {/* Remove the single star alignment */}
      </div>
      
      <div className="relative z-10">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center justify-center mb-12">
            <Star className="mr-3 w-8 h-8 text-white dark:text-gray-300 animate-bounce" />
            <h2 className="text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-300 dark:from-gray-300 dark:to-white">
              Skills & Expertise
            </h2>
          </div>

          {Object.entries(groupedSkills).map(([category, skills]) => (
            <div key={category} className="mb-16">
              <h3 className="text-2xl font-bold mb-6 dark:text-gray-100 flex items-center">
                <span className="bg-blue-500 dark:bg-blue-400 w-2 h-2 rounded-full mr-3" />
                {category}
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
                {skills.map((skill) => (
                  <div 
                    key={skill.name} 
                    className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg dark:shadow-none border border-gray-200 dark:border-gray-700 transition-all duration-300 hover:scale-[1.02]"
                  >
                    <div className="flex items-center mb-2">
                      <div className="opacity-50 group-hover:opacity-100 transition-opacity duration-300">
                        <img 
                          src={skill.icon} 
                          alt={`${skill.name} logo`} 
                          className="skill-icon"
                          loading="lazy"
                          width="24"
                          height="24"
                        />
                      </div>
                    </div>
                    <h4 className="text-lg font-semibold dark:text-gray-100">{skill.name}</h4>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;
