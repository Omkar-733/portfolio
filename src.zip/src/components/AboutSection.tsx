import React, { useState, useEffect, useRef } from 'react';
import { User, Code, Sparkles, Trophy, Heart, Star, Zap, Target, Brain, Coffee } from 'lucide-react';

const AboutSection: React.FC = () => {
  const [hoveredSkill, setHoveredSkill] = useState<string | null>(null);
  const [clickedCard, setClickedCard] = useState<string | null>(null);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [isVisible, setIsVisible] = useState(false);
  const [floatingParticles, setFloatingParticles] = useState<Array<{id: number, x: number, y: number, delay: number}>>([]);
  const sectionRef = useRef<HTMLDivElement>(null);

  // Initialize floating particles
  useEffect(() => {
    const particles = Array.from({ length: 15 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      delay: Math.random() * 5
    }));
    setFloatingParticles(particles);
  }, []);

  // Intersection Observer for scroll animations
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => setIsVisible(entry.isIntersecting),
      { threshold: 0.1 }
    );
    
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  // Mouse tracking for interactive effects
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (sectionRef.current) {
        const rect = sectionRef.current.getBoundingClientRect();
        setMousePosition({
          x: ((e.clientX - rect.left) / rect.width) * 100,
          y: ((e.clientY - rect.top) / rect.height) * 100
        });
      }
    };

    const section = sectionRef.current;
    if (section) {
      section.addEventListener('mousemove', handleMouseMove);
      return () => section.removeEventListener('mousemove', handleMouseMove);
    }
  }, []);

  const skills = [
    { name: "Full Stack Development", icon: Code, color: "from-blue-500 to-cyan-500", level: 90 },
    { name: "AI/ML", icon: Brain, color: "from-purple-500 to-pink-500", level: 85 },
    { name: "Problem Solving", icon: Target, color: "from-green-500 to-emerald-500", level: 95 },
    { name: "Teamwork", icon: Heart, color: "from-red-500 to-rose-500", level: 92 },
    { name: "UI/UX Design", icon: Sparkles, color: "from-yellow-500 to-orange-500", level: 88 },
    { name: "Adaptability", icon: Zap, color: "from-indigo-500 to-purple-500", level: 93 }
  ];

  const experiences = [
    {
      id: "vpt",
      company: "Visakhapatnam Port Trust",
      role: "Internship - Problem Solving & Computer Skills",
      icon: Trophy,
      achievements: ["Solved 15+ complex computational problems", "Improved system efficiency by 25%", "Led a team of 3 interns"]
    },
    {
      id: "vsp",
      company: "Visakhapatnam Steel Plant",
      role: "Defect Handling System Developer",
      icon: Star,
      achievements: ["Developed automated defect tracking system", "Reduced processing time by 40%", "Integrated ML-based prediction models"]
    }
  ];

  return (
    <section 
      ref={sectionRef}
      id="about" 
      className="py-20 px-4 border-t border-gray-200 dark:border-gray-800 relative overflow-hidden min-h-screen"
      style={{
        background: `radial-gradient(circle at ${mousePosition.x}% ${mousePosition.y}%, rgba(59, 130, 246, 0.1) 0%, transparent 50%)`
      }}
    >
      {/* Animated floating particles */}
      {floatingParticles.map((particle) => (
        <div
          key={particle.id}
          className="absolute w-2 h-2 bg-blue-400/30 rounded-full pointer-events-none"
          style={{
            left: `${particle.x}%`,
            top: `${particle.y}%`,
            animation: `float 6s ease-in-out infinite ${particle.delay}s`
          }}
        />
      ))}

      {/* Dynamic background gradient */}
      <div 
        className="absolute inset-0 pointer-events-none transition-all duration-1000"
        style={{
          background: `
            radial-gradient(circle at ${mousePosition.x}% ${mousePosition.y}%, rgba(59, 130, 246, 0.05) 0%, transparent 50%),
            linear-gradient(135deg, rgba(168, 85, 247, 0.02) 0%, rgba(59, 130, 246, 0.02) 100%)
          `
        }}
      />
      
      <div className="relative z-10">
        <div className="max-w-6xl mx-auto">
          {/* Animated Header */}
          <div className={`flex items-center justify-center mb-16 transform transition-all duration-1000 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
            <User className="mr-4 w-10 h-10 text-blue-500 dark:text-blue-400 animate-pulse" />
            <h2 className="text-5xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 dark:from-blue-400 dark:via-purple-400 dark:to-pink-400 animate-gradient-x">
              About Me
            </h2>
            <Coffee className="ml-4 w-8 h-8 text-amber-500 animate-bounce" />
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* Left Column - Profile & Experience */}
            <div className="space-y-8">
              {/* Profile Card */}
              <div 
                className={`group bg-white dark:bg-gray-800 rounded-2xl p-8 shadow-2xl dark:shadow-none border border-gray-200 dark:border-gray-700 transform transition-all duration-700 hover:scale-105 hover:rotate-1 cursor-pointer ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}`}
                onClick={() => setClickedCard(clickedCard === 'profile' ? null : 'profile')}
                style={{ animationDelay: '0.2s' }}
              >
                <div className="flex items-center justify-center mb-6 relative">
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full blur-xl opacity-30 group-hover:opacity-50 transition-opacity duration-300 animate-pulse" />
                  <Code className="w-16 h-16 text-blue-500 dark:text-blue-400 relative z-10 transform group-hover:rotate-12 transition-transform duration-300" />
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-gray-800 dark:text-gray-200 mb-2 group-hover:text-blue-500 transition-colors duration-300">
                    Full Stack Developer
                  </p>
                  <p className="text-gray-600 dark:text-gray-400 group-hover:text-gray-500 transition-colors duration-300">
                    Bachelor of Technology Student
                  </p>
                </div>
                {clickedCard === 'profile' && (
                  <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg animate-slideDown">
                    <p className="text-sm text-blue-800 dark:text-blue-200">
                      🎓 Currently pursuing BTech with focus on cutting-edge technologies and innovative problem-solving approaches.
                    </p>
                  </div>
                )}
              </div>

              {/* Experience Cards */}
              {experiences.map((exp, index) => (
                <div
                  key={exp.id}
                  className={`group bg-white dark:bg-gray-800 rounded-2xl p-8 shadow-2xl dark:shadow-none border border-gray-200 dark:border-gray-700 transform transition-all duration-700 hover:scale-105 hover:-rotate-1 cursor-pointer ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}`}
                  onClick={() => setClickedCard(clickedCard === exp.id ? null : exp.id)}
                  style={{ animationDelay: `${0.4 + index * 0.2}s` }}
                >
                  <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0">
                      <exp.icon className="w-8 h-8 text-blue-500 dark:text-blue-400 group-hover:animate-bounce" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-semibold text-gray-800 dark:text-gray-200 mb-2 group-hover:text-blue-500 transition-colors duration-300">
                        {exp.company}
                      </h3>
                      <p className="text-gray-600 dark:text-gray-400 group-hover:text-gray-500 transition-colors duration-300">
                        {exp.role}
                      </p>
                    </div>
                  </div>
                  
                  {clickedCard === exp.id && (
                    <div className="mt-6 space-y-2 animate-slideDown">
                      <h4 className="font-semibold text-blue-600 dark:text-blue-400">Key Achievements:</h4>
                      {exp.achievements.map((achievement, i) => (
                        <div key={i} className="flex items-center space-x-2 animate-fadeIn" style={{ animationDelay: `${i * 0.1}s` }}>
                          <Sparkles className="w-4 h-4 text-yellow-500" />
                          <span className="text-sm text-gray-700 dark:text-gray-300">{achievement}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Right Column - Skills & Interests */}
            <div className="space-y-8">
              {/* Skills Card */}
              <div className={`bg-white dark:bg-gray-800 rounded-2xl p-8 shadow-2xl dark:shadow-none border border-gray-200 dark:border-gray-700 transform transition-all duration-700 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}`} style={{ animationDelay: '0.6s' }}>
                <h3 className="text-2xl font-semibold text-gray-800 dark:text-gray-200 mb-8 text-center">
                  Technical Skills
                </h3>
                <div className="space-y-6">
                  {skills.map((skill, index) => (
                    <div
                      key={skill.name}
                      className="group cursor-pointer"
                      onMouseEnter={() => setHoveredSkill(skill.name)}
                      onMouseLeave={() => setHoveredSkill(null)}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-3">
                          <skill.icon className={`w-5 h-5 transform transition-all duration-300 ${hoveredSkill === skill.name ? 'scale-125 rotate-12' : ''}`} />
                          <span className={`font-medium transition-colors duration-300 ${hoveredSkill === skill.name ? 'text-blue-500' : 'text-gray-700 dark:text-gray-300'}`}>
                            {skill.name}
                          </span>
                        </div>
                        <span className={`text-sm font-semibold transition-all duration-300 ${hoveredSkill === skill.name ? 'text-blue-500 scale-110' : 'text-gray-500'}`}>
                          {skill.level}%
                        </span>
                      </div>
                      <div className="relative h-3 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                        <div 
                          className={`absolute left-0 top-0 h-full bg-gradient-to-r ${skill.color} rounded-full transition-all duration-1000 ease-out`}
                          style={{ 
                            width: hoveredSkill === skill.name ? `${skill.level}%` : '0%',
                            boxShadow: hoveredSkill === skill.name ? '0 0 20px rgba(59, 130, 246, 0.5)' : 'none'
                          }}
                        />
                        {hoveredSkill === skill.name && (
                          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent animate-shimmer" />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Interests Card */}
              <div className={`group bg-white dark:bg-gray-800 rounded-2xl p-8 shadow-2xl dark:shadow-none border border-gray-200 dark:border-gray-700 transform transition-all duration-700 hover:scale-105 cursor-pointer ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}`} style={{ animationDelay: '0.8s' }}>
                <h3 className="text-2xl font-semibold text-gray-800 dark:text-gray-200 mb-6 flex items-center justify-center">
                  <Heart className="w-6 h-6 mr-2 text-red-500 group-hover:animate-pulse" />
                  Interests & Passion
                </h3>
                <div className="relative overflow-hidden">
                  <p className="text-gray-600 dark:text-gray-400 leading-relaxed group-hover:text-gray-700 dark:group-hover:text-gray-300 transition-colors duration-300">
                    I'm passionate about exploring new technologies and contributing to innovative projects. I actively participate in hackathons and enjoy staying updated with the latest developments in web development and artificial intelligence.
                  </p>
                  <div className="mt-6 flex flex-wrap gap-3">
                    {['🚀 Innovation', '💡 Hackathons', '🤖 AI Research', '🌐 Web Dev', '📱 Mobile Apps'].map((interest, i) => (
                      <span 
                        key={i}
                        className="px-4 py-2 bg-gradient-to-r from-purple-500/10 to-pink-500/10 rounded-full text-sm font-medium text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-700 hover:scale-110 transform transition-all duration-300 cursor-pointer animate-fadeIn"
                        style={{ animationDelay: `${i * 0.1}s` }}
                      >
                        {interest}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Custom CSS animations */}
      <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-20px) rotate(180deg); }
        }
        
        @keyframes gradient-x {
          0%, 100% { background-size: 200% 200%; background-position: left center; }
          50% { background-size: 200% 200%; background-position: right center; }
        }
        
        @keyframes slideDown {
          from { opacity: 0; transform: translateY(-10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        
        @keyframes fadeIn {
          from { opacity: 0; transform: scale(0.9); }
          to { opacity: 1; transform: scale(1); }
        }
        
        @keyframes shimmer {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
        
        .animate-gradient-x { animation: gradient-x 3s ease infinite; }
        .animate-slideDown { animation: slideDown 0.5s ease-out forwards; }
        .animate-fadeIn { animation: fadeIn 0.5s ease-out forwards; }
        .animate-shimmer { animation: shimmer 1.5s ease-in-out infinite; }
      `}</style>
    </section>
  );
};

export default AboutSection;